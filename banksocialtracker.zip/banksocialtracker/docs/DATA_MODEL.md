# Firestore data model

All timestamps are Firestore `Timestamp`. A **date key** is a `YYYY-MM-DD` string for the calendar day in **Asia/Dhaka**.
Only server code (Admin SDK) reads or writes; `firestore.rules` denies all client access.

## `banks/{bankId}`
`bankId` = ASCII slug of the Facebook handle (e.g. `brac-bank`). Immutable.

```json
{
  "id": "brac-bank",
  "name": "BRAC Bank PLC",
  "short_name": "BRAC",
  "category": "private",                  // state-owned | private | islamic | foreign | specialized
  "facebook_url": "https://www.facebook.com/bracbank",
  "facebook_handle": "bracbank",
  "is_active": true,                      // ingestion fetches only active banks
  "last_fetched_at": "<Timestamp|null>",
  "last_fetch_status": "ok",              // ok | error | null
  "last_fetch_count": 3,
  "last_error": null,
  "created_by": "<uid>",
  "created_at": "<Timestamp>",
  "updated_at": "<Timestamp>"
}
```

## `posts/{bankId}_{fbPostId}`
Deterministic ID ⇒ re-fetching the same post is an idempotent upsert (no duplicates, engagement counts refresh).

```json
{
  "id": "brac-bank_1234567890",
  "bank_id": "brac-bank",
  "bank_name": "BRAC Bank PLC",           // denormalized (kept in sync by PATCH /api/admin/banks/[id])
  "bank_short_name": "BRAC",
  "bank_category": "private",             // denormalized so category filtering needs no join
  "fb_post_id": "1234567890",
  "permalink": "https://www.facebook.com/bracbank/posts/1234567890",
  "caption": "ঈদ মোবারক! ...",
  "post_date": "2026-03-21",              // Asia/Dhaka calendar day — the primary query key
  "posted_at": "<Timestamp>",             // exact instant (UTC under the hood)
  "media_type": "photo",                  // photo | video | album | text
  "media": [
    {
      "kind": "image",                    // image | video
      "url": "https://firebasestorage.googleapis.com/...",   // cached copy if available, else FB CDN URL
      "original_url": "https://scontent...fbcdn.net/...",
      "video_url": null,                  // direct video URL (expires); UI links to Facebook for playback
      "cached": true
    }
  ],
  "reactions_count": 1240,
  "comments_count": 58,
  "shares_count": 31,
  "source": "apify",
  "first_seen_at": "<Timestamp>",         // set once, on first insert
  "last_synced_at": "<Timestamp>"
}
```

## `campaigns/{slug-year}`
```json
{
  "id": "eid-ul-fitr-2026",
  "name": "Eid-ul-Fitr",
  "name_bn": null,
  "dates": ["2026-03-21", "2026-03-22"],  // date keys; festival dates shift every year, so they are data, not code
  "color": "#16a34a",
  "description": null,
  "is_active": true,
  "created_by": "<uid>",
  "created_at": "<Timestamp>",
  "updated_at": "<Timestamp>"
}
```
Posts are **not** tagged with campaigns. A campaign is just a named set of dates, so adding or editing one never requires rewriting posts.

## Composite indexes (`firestore.indexes.json`)

| # | Fields | Serves |
|---|--------|--------|
| 1 | `post_date ↑, posted_at ↓` | day / date-range view, no other filter |
| 2 | `bank_id ↑, post_date ↑, posted_at ↓` | one bank on a day / range |
| 3 | `bank_category ↑, post_date ↑, posted_at ↓` | one category on a day / range |

Every query is `post_date >= from AND post_date <= to` (a single day is `from == to`), optionally with one equality
filter, ordered by `post_date, posted_at desc`. Equality fields come first in the index, then the range/order fields.
`banks` and `campaigns` queries use a single equality filter and sort in memory, so they need no composite index.

**Keyword search** is done in memory on the day's result set (≈ 50 banks × a few posts). Firestore has no substring
search; if you outgrow this (multi-month full-text), add Typesense/Algolia and keep Firestore as the source of truth.
