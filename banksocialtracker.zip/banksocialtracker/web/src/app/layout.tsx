import type { Metadata } from "next";
import { Inter, Noto_Sans_Bengali } from "next/font/google";
import { AuthProvider } from "@/components/auth-provider";
import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
// Bank captions are frequently Bengali; load a real Bengali face instead of relying on OS fallback.
const bengali = Noto_Sans_Bengali({ subsets: ["bengali", "latin"], variable: "--font-bengali" });

export const metadata: Metadata = {
  title: "BankSocialTracker",
  description: "Daily Facebook posts from Bangladeshi banks, by date.",
  robots: { index: false, follow: false }, // internal tool
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body
        className={`${inter.variable} ${bengali.variable} antialiased`}
        style={{ fontFamily: "var(--font-inter), var(--font-bengali), system-ui, sans-serif" }}
      >
        <AuthProvider>{children}</AuthProvider>
      </body>
    </html>
  );
}
