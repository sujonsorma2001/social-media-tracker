import { AppShell } from "@/components/app-shell";
import { BanksAdmin } from "@/components/admin/banks-admin";

export default function AdminBanksPage() {
  return (
    <AppShell>
      <BanksAdmin />
    </AppShell>
  );
}
