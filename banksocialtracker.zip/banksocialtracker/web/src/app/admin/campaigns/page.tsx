import { AppShell } from "@/components/app-shell";
import { CampaignsAdmin } from "@/components/admin/campaigns-admin";

export default function AdminCampaignsPage() {
  return (
    <AppShell>
      <CampaignsAdmin />
    </AppShell>
  );
}
