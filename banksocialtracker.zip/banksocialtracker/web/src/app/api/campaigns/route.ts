import { NextResponse } from "next/server";
import { route } from "@/lib/api";
import { requireUser } from "@/lib/auth-server";
import { adminDb } from "@/lib/firebase-admin";
import { serializeCampaign } from "@/lib/serialize";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export const GET = route(async (req) => {
  await requireUser(req);
  const snap = await adminDb().collection("campaigns").where("is_active", "==", true).get();
  const campaigns = snap.docs.map(serializeCampaign).sort((a, b) => (b.dates[0] ?? "").localeCompare(a.dates[0] ?? ""));
  return NextResponse.json({ campaigns }, { headers: { "Cache-Control": "private, max-age=60" } });
});
