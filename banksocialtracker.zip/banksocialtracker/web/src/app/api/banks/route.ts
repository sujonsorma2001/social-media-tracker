import { NextResponse } from "next/server";
import { route } from "@/lib/api";
import { requireUser } from "@/lib/auth-server";
import { adminDb } from "@/lib/firebase-admin";
import { serializeBankSummary } from "@/lib/serialize";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Active banks for the filter dropdown. Public fields only (no sync errors). */
export const GET = route(async (req) => {
  await requireUser(req);
  const snap = await adminDb().collection("banks").where("is_active", "==", true).get();
  const banks = snap.docs.map(serializeBankSummary).sort((a, b) => a.name.localeCompare(b.name));
  return NextResponse.json({ banks }, { headers: { "Cache-Control": "private, max-age=60" } });
});
