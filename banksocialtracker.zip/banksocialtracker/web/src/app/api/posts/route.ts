import { NextResponse } from "next/server";
import type { Query } from "firebase-admin/firestore";
import { z } from "zod";
import { ApiError, firestoreCode, route } from "@/lib/api";
import { requireUser } from "@/lib/auth-server";
import { daysBetweenKeys, isValidDateKey } from "@/lib/date";
import { adminDb } from "@/lib/firebase-admin";
import { serializePost } from "@/lib/serialize";
import { BANK_CATEGORIES, type PostsResponse } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Hard cap on documents read per request. One festival day across ~50 banks is far below this. */
const MAX_READ = 1000;
const MAX_RANGE_DAYS = 62;

const dateKey = z.string().refine(isValidDateKey, "Expected a real date as YYYY-MM-DD");

const querySchema = z.object({
  date: dateKey.optional(),
  from: dateKey.optional(),
  to: dateKey.optional(),
  bank_id: z.string().regex(/^[a-z0-9-]+$/).max(100).optional(),
  category: z.enum(BANK_CATEGORIES).optional(),
  q: z.string().max(100).optional(),
});

/**
 * GET /api/posts?date=2026-04-14[&bank_id=…|&category=…][&q=eid mubarak]
 * GET /api/posts?from=2026-03-20&to=2026-03-22
 *
 * Firestore does the date/bank/category filtering (indexed); keyword search runs in memory on
 * that already-small result set, because Firestore has no substring search.
 */
export const GET = route(async (req) => {
  await requireUser(req);

  const params = Object.fromEntries([...new URL(req.url).searchParams].filter(([, v]) => v.trim() !== ""));
  const f = querySchema.parse(params);

  const from = f.date ?? f.from;
  const to = f.date ?? f.to ?? from;
  if (!from || !to) throw new ApiError(400, "Provide `date`, or `from` and `to`");
  if (from > to) throw new ApiError(400, "`from` must not be after `to`");
  if (daysBetweenKeys(from, to) > MAX_RANGE_DAYS) throw new ApiError(400, `Date range cannot exceed ${MAX_RANGE_DAYS} days`);

  // A single date is just a one-day range, so every query shape shares the same 3 composite indexes.
  let query: Query = adminDb().collection("posts").where("post_date", ">=", from).where("post_date", "<=", to);
  if (f.bank_id) query = query.where("bank_id", "==", f.bank_id);
  else if (f.category) query = query.where("bank_category", "==", f.category);
  query = query.orderBy("post_date").orderBy("posted_at", "desc").limit(MAX_READ + 1);

  let snap;
  try {
    snap = await query.get();
  } catch (err) {
    if (firestoreCode(err) === 9) {
      console.error("[api/posts] Missing Firestore index. Run `firebase deploy --only firestore:indexes`.", err);
      throw new ApiError(500, "The database index for this query is still building or not deployed");
    }
    throw err;
  }

  const truncated = snap.size > MAX_READ;
  let posts = snap.docs.slice(0, MAX_READ).map(serializePost);

  const tokens = (f.q ?? "").normalize("NFC").toLocaleLowerCase().split(/\s+/).filter(Boolean);
  if (tokens.length > 0) {
    posts = posts.filter((p) => {
      const haystack = p.caption.normalize("NFC").toLocaleLowerCase();
      return tokens.every((t) => haystack.includes(t));
    });
  }

  const body: PostsResponse = {
    posts,
    count: posts.length,
    banks_with_posts: new Set(posts.map((p) => p.bank_id)).size,
    truncated,
  };
  return NextResponse.json(body, { headers: { "Cache-Control": "private, max-age=30" } });
});
