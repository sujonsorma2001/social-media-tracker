import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { ApiError, firestoreCode, readJson, route } from "@/lib/api";
import { requireAdmin } from "@/lib/auth-server";
import { bankCreateSchema, bankIdFromHandle, parseFacebookUrl } from "@/lib/banks";
import { adminDb } from "@/lib/firebase-admin";
import { serializeBank } from "@/lib/serialize";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** All banks including inactive ones, with last-sync status. */
export const GET = route(async (req) => {
  await requireAdmin(req);
  const snap = await adminDb().collection("banks").orderBy("name").get();
  return NextResponse.json({ banks: snap.docs.map(serializeBank) });
});

export const POST = route(async (req) => {
  const admin = await requireAdmin(req);
  const body = bankCreateSchema.parse(await readJson(req));

  const page = parseFacebookUrl(body.facebook_url);
  if (!page) throw new ApiError(400, "Invalid Facebook page URL"); // unreachable after validation; keeps types honest
  const id = bankIdFromHandle(page.handle);
  if (!id) throw new ApiError(400, "Could not derive an ID from that page handle");

  try {
    await adminDb().collection("banks").doc(id).create({
      id,
      name: body.name,
      short_name: body.short_name || null,
      category: body.category,
      facebook_url: page.canonicalUrl,
      facebook_handle: page.handle,
      is_active: body.is_active ?? true,
      last_fetched_at: null,
      last_fetch_status: null,
      last_error: null,
      created_by: admin.uid,
      created_at: FieldValue.serverTimestamp(),
      updated_at: FieldValue.serverTimestamp(),
    });
  } catch (err) {
    if (firestoreCode(err) === 6) throw new ApiError(409, "A bank with this Facebook page already exists");
    throw err;
  }
  return NextResponse.json({ id }, { status: 201 });
});
