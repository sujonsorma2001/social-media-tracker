import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { ApiError, readJson, route } from "@/lib/api";
import { requireAdmin } from "@/lib/auth-server";
import { BANK_ID_PATTERN, bankUpdateSchema, parseFacebookUrl } from "@/lib/banks";
import { propagateBankToPosts } from "@/lib/bank-sync";
import { adminDb } from "@/lib/firebase-admin";
import type { BankCategory } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface Ctx {
  params: Promise<{ id: string }>;
}

/** Edit a bank or toggle `is_active`. The document ID (derived from the handle) never changes. */
export const PATCH = route<Ctx>(async (req, { params }) => {
  await requireAdmin(req);
  const { id } = await params;
  if (!BANK_ID_PATTERN.test(id)) throw new ApiError(400, "Invalid bank id");

  const body = bankUpdateSchema.parse(await readJson(req));
  const ref = adminDb().collection("banks").doc(id);
  const snap = await ref.get();
  if (!snap.exists) throw new ApiError(404, "Bank not found");

  const update: Record<string, unknown> = { updated_at: FieldValue.serverTimestamp() };
  if (body.name !== undefined) update.name = body.name;
  if (body.short_name !== undefined) update.short_name = body.short_name || null;
  if (body.category !== undefined) update.category = body.category;
  if (body.is_active !== undefined) update.is_active = body.is_active;
  if (body.facebook_url !== undefined) {
    const page = parseFacebookUrl(body.facebook_url);
    if (!page) throw new ApiError(400, "Invalid Facebook page URL");
    update.facebook_url = page.canonicalUrl;
    update.facebook_handle = page.handle;
  }
  await ref.update(update);

  // Keep denormalized fields on existing posts consistent.
  const denormChanged = body.name !== undefined || body.short_name !== undefined || body.category !== undefined;
  if (denormChanged) {
    const after = (await ref.get()).data() ?? {};
    await propagateBankToPosts(id, {
      bank_name: String(after.name ?? ""),
      bank_short_name: typeof after.short_name === "string" ? after.short_name : null,
      bank_category: after.category as BankCategory,
    });
  }
  return NextResponse.json({ ok: true });
});
