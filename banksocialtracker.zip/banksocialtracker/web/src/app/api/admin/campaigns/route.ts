import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { z } from "zod";
import { ApiError, firestoreCode, readJson, route } from "@/lib/api";
import { requireAdmin } from "@/lib/auth-server";
import { isValidDateKey } from "@/lib/date";
import { adminDb } from "@/lib/firebase-admin";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const campaignSchema = z.object({
  name: z.string().trim().min(2).max(80),
  name_bn: z.string().trim().max(80).optional(),
  dates: z.array(z.string().refine(isValidDateKey, "Expected YYYY-MM-DD")).min(1).max(31),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/, "Expected a hex color like #16a34a").optional(),
  description: z.string().trim().max(300).optional(),
});

const slugify = (s: string): string => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");

export const POST = route(async (req) => {
  const admin = await requireAdmin(req);
  const body = campaignSchema.parse(await readJson(req));

  const dates = [...new Set(body.dates)].sort();
  // Year suffix keeps "Eid-ul-Fitr 2026" and "Eid-ul-Fitr 2027" distinct.
  const id = slugify(`${body.name}-${(dates[0] ?? "").slice(0, 4)}`);
  if (!id) throw new ApiError(400, "Campaign name must contain letters or digits");

  try {
    await adminDb().collection("campaigns").doc(id).create({
      id,
      name: body.name,
      name_bn: body.name_bn || null,
      dates,
      color: body.color ?? "#2563eb",
      description: body.description || null,
      is_active: true,
      created_by: admin.uid,
      created_at: FieldValue.serverTimestamp(),
      updated_at: FieldValue.serverTimestamp(),
    });
  } catch (err) {
    if (firestoreCode(err) === 6) throw new ApiError(409, "A campaign with this name and year already exists");
    throw err;
  }
  return NextResponse.json({ id }, { status: 201 });
});
