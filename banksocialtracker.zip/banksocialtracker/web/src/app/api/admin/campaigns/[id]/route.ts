import { NextResponse } from "next/server";
import { ApiError, route } from "@/lib/api";
import { requireAdmin } from "@/lib/auth-server";
import { adminDb } from "@/lib/firebase-admin";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface Ctx {
  params: Promise<{ id: string }>;
}

export const DELETE = route<Ctx>(async (req, { params }) => {
  await requireAdmin(req);
  const { id } = await params;
  if (!/^[a-z0-9][a-z0-9-]{0,99}$/.test(id)) throw new ApiError(400, "Invalid campaign id");
  await adminDb().collection("campaigns").doc(id).delete();
  return NextResponse.json({ ok: true });
});
