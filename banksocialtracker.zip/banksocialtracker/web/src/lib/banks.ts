import { z } from "zod";
import { BANK_CATEGORIES } from "./types";

export interface ParsedFacebookUrl {
  handle: string;
  canonicalUrl: string;
}

/** Accepts facebook.com/<handle> and facebook.com/profile.php?id=<digits>. Returns null for anything else. */
export function parseFacebookUrl(input: string): ParsedFacebookUrl | null {
  let url: URL;
  try {
    url = new URL(input.trim());
  } catch {
    return null;
  }
  const host = url.hostname.toLowerCase();
  if (!(host === "facebook.com" || host.endsWith(".facebook.com") || host === "fb.com")) return null;

  if (url.pathname.replace(/\/+$/, "") === "/profile.php") {
    const id = url.searchParams.get("id");
    return id && /^\d+$/.test(id) ? { handle: id, canonicalUrl: `https://www.facebook.com/profile.php?id=${id}` } : null;
  }
  const handle = url.pathname.split("/").filter(Boolean)[0];
  if (!handle || !/^[\w.-]{3,100}$/.test(handle)) return null;
  if (["pages", "groups", "watch", "share", "people", "public"].includes(handle.toLowerCase())) return null;
  return { handle, canonicalUrl: `https://www.facebook.com/${handle}` };
}

/** Stable Firestore ID derived from the page handle (ASCII slug). */
export const bankIdFromHandle = (handle: string): string =>
  handle.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");

export const BANK_ID_PATTERN = /^[a-z0-9][a-z0-9-]{0,99}$/;

const facebookUrl = z
  .string()
  .trim()
  .max(300)
  .refine((v) => parseFacebookUrl(v) !== null, {
    message: "Use the page URL, e.g. https://www.facebook.com/yourbank (or profile.php?id=…)",
  });

export const bankCreateSchema = z.object({
  name: z.string().trim().min(2).max(120),
  short_name: z.string().trim().max(30).optional(),
  category: z.enum(BANK_CATEGORIES),
  facebook_url: facebookUrl,
  is_active: z.boolean().optional(),
});

export const bankUpdateSchema = bankCreateSchema
  .partial()
  .refine((v) => Object.keys(v).length > 0, { message: "Provide at least one field to update" });
