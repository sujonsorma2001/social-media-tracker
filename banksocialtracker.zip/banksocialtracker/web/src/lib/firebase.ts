import { getApp, getApps, initializeApp, type FirebaseApp, type FirebaseOptions } from "firebase/app";
import { getAuth, GoogleAuthProvider, type Auth } from "firebase/auth";

/**
 * Browser Firebase setup. Only Auth is used client-side; Firestore is read through our API routes.
 *
 * Next.js inlines NEXT_PUBLIC_* variables at build time ONLY for literal `process.env.NAME`
 * accesses, so every variable is spelled out here (no dynamic lookup).
 */
const raw = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
} as const;

function buildConfig(): FirebaseOptions {
  const missing = Object.entries(raw)
    .filter(([, value]) => !value)
    .map(([key]) => key);
  if (missing.length > 0) {
    throw new Error(
      `Missing Firebase client config: ${missing.join(", ")}. ` +
        `Set the NEXT_PUBLIC_FIREBASE_* variables (.env.local locally, Project Settings → Environment Variables on Vercel) and redeploy.`,
    );
  }
  return raw as FirebaseOptions;
}

/** Safe under Next.js hot reload and multiple imports. */
export const app: FirebaseApp = getApps().length > 0 ? getApp() : initializeApp(buildConfig());
export const auth: Auth = getAuth(app);

export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: "select_account" });
