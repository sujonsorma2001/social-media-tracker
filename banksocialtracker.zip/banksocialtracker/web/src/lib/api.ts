import { NextResponse } from "next/server";
import { ZodError } from "zod";

export class ApiError extends Error {
  constructor(
    public readonly status: number,
    message: string,
    public readonly details?: unknown,
  ) {
    super(message);
    this.name = "ApiError";
  }
}

type Handler<C> = (req: Request, ctx: C) => Promise<Response>;

/** Wraps a route handler so every failure becomes a consistent JSON error. */
export function route<C = unknown>(handler: Handler<C>): Handler<C> {
  return async (req, ctx) => {
    try {
      return await handler(req, ctx);
    } catch (err) {
      if (err instanceof ApiError) {
        return NextResponse.json({ error: err.message, details: err.details }, { status: err.status });
      }
      if (err instanceof ZodError) {
        const issues = err.issues.map((i) => ({ path: i.path.join("."), message: i.message }));
        return NextResponse.json({ error: "Invalid request", details: issues }, { status: 400 });
      }
      console.error(`[api] ${req.method} ${new URL(req.url).pathname} failed:`, err);
      return NextResponse.json({ error: "Internal server error" }, { status: 500 });
    }
  };
}

export async function readJson(req: Request): Promise<unknown> {
  try {
    return await req.json();
  } catch {
    throw new ApiError(400, "Request body must be valid JSON");
  }
}

/** gRPC status code carried by Firestore errors (6 = ALREADY_EXISTS, 9 = FAILED_PRECONDITION). */
export function firestoreCode(err: unknown): number | null {
  if (typeof err === "object" && err !== null && "code" in err && typeof (err as { code: unknown }).code === "number") {
    return (err as { code: number }).code;
  }
  return null;
}
