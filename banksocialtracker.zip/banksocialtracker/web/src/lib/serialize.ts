import { Timestamp, type DocumentData, type DocumentSnapshot } from "firebase-admin/firestore";
import type { Bank, BankSummary, Campaign, Post } from "./types";

const iso = (v: unknown): string | null => (v instanceof Timestamp ? v.toDate().toISOString() : null);
const text = (v: unknown, fallback = ""): string => (typeof v === "string" ? v : fallback);
const count = (v: unknown): number => (typeof v === "number" && Number.isFinite(v) ? v : 0);

type Snap = DocumentSnapshot<DocumentData>;

export function serializeBankSummary(snap: Snap): BankSummary {
  const d = snap.data() ?? {};
  return {
    id: snap.id,
    name: text(d.name),
    short_name: typeof d.short_name === "string" ? d.short_name : null,
    category: d.category as BankSummary["category"],
    facebook_url: text(d.facebook_url),
  };
}

export function serializeBank(snap: Snap): Bank {
  const d = snap.data() ?? {};
  return {
    ...serializeBankSummary(snap),
    facebook_handle: text(d.facebook_handle),
    is_active: d.is_active === true,
    last_fetched_at: iso(d.last_fetched_at),
    last_fetch_status: d.last_fetch_status === "ok" || d.last_fetch_status === "error" ? d.last_fetch_status : null,
    last_error: typeof d.last_error === "string" ? d.last_error : null,
    created_at: iso(d.created_at),
    updated_at: iso(d.updated_at),
  };
}

export function serializePost(snap: Snap): Post {
  const d = snap.data() ?? {};
  return {
    id: snap.id,
    bank_id: text(d.bank_id),
    bank_name: text(d.bank_name),
    bank_short_name: typeof d.bank_short_name === "string" ? d.bank_short_name : null,
    bank_category: d.bank_category as Post["bank_category"],
    fb_post_id: text(d.fb_post_id),
    permalink: text(d.permalink),
    caption: text(d.caption),
    post_date: text(d.post_date),
    posted_at: iso(d.posted_at) ?? "",
    media_type: d.media_type as Post["media_type"],
    media: Array.isArray(d.media) ? (d.media as Post["media"]) : [],
    reactions_count: count(d.reactions_count),
    comments_count: count(d.comments_count),
    shares_count: count(d.shares_count),
  };
}

export function serializeCampaign(snap: Snap): Campaign {
  const d = snap.data() ?? {};
  return {
    id: snap.id,
    name: text(d.name),
    name_bn: typeof d.name_bn === "string" ? d.name_bn : null,
    dates: Array.isArray(d.dates) ? d.dates.filter((x): x is string => typeof x === "string") : [],
    color: text(d.color, "#2563eb"),
    description: typeof d.description === "string" ? d.description : null,
    is_active: d.is_active !== false,
  };
}
