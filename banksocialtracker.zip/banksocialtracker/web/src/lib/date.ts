/**
 * Date helpers. A "date key" is always `YYYY-MM-DD` in Asia/Dhaka.
 * The server half KEEPS IN SYNC with ingestion/src/date.ts.
 *
 * Never use `date.toISOString().slice(0, 10)` for calendar picks: it converts to UTC and can
 * shift the day by one for users whose local midnight differs from UTC.
 */
export const DHAKA_TZ = "Asia/Dhaka";

const dhakaFormatter = new Intl.DateTimeFormat("en-US", {
  timeZone: DHAKA_TZ,
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
});

export function toDhakaDateKey(date: Date): string {
  const parts = dhakaFormatter.formatToParts(date);
  const pick = (type: Intl.DateTimeFormatPartTypes): string => {
    const value = parts.find((p) => p.type === type)?.value;
    if (!value) throw new Error(`Intl did not return a "${type}" part`);
    return value;
  };
  return `${pick("year")}-${pick("month")}-${pick("day")}`;
}

export const todayInDhaka = (): string => toDhakaDateKey(new Date());

export function isValidDateKey(key: string): boolean {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(key);
  if (!m) return false;
  const y = Number(m[1]);
  const mo = Number(m[2]);
  const d = Number(m[3]);
  const dt = new Date(Date.UTC(y, mo - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === mo - 1 && dt.getUTCDate() === d;
}

/** Whole days from `a` to `b` (both date keys). */
export function daysBetweenKeys(a: string, b: string): number {
  const [ay, am, ad] = a.split("-").map(Number) as [number, number, number];
  const [by, bm, bd] = b.split("-").map(Number) as [number, number, number];
  return Math.round((Date.UTC(by, bm - 1, bd) - Date.UTC(ay, am - 1, ad)) / 86_400_000);
}

/** Local-calendar Date (what the calendar widget shows) → date key, using LOCAL components. */
export function localDateToKey(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

/** Date key → local-midnight Date for the calendar widget. */
export function keyToLocalDate(key: string): Date {
  const [y, m, d] = key.split("-").map(Number) as [number, number, number];
  return new Date(y, m - 1, d);
}

export function formatDateLong(key: string): string {
  return keyToLocalDate(key).toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
}

export function formatDateShort(key: string): string {
  return keyToLocalDate(key).toLocaleDateString("en-GB", { day: "numeric", month: "short" });
}

const timeFormatter = new Intl.DateTimeFormat("en-GB", { timeZone: DHAKA_TZ, hour: "numeric", minute: "2-digit", hour12: true });
export const formatDhakaTime = (iso: string): string => timeFormatter.format(new Date(iso));

const dateTimeFormatter = new Intl.DateTimeFormat("en-GB", { timeZone: DHAKA_TZ, dateStyle: "medium", timeStyle: "short" });
export const formatDhakaDateTime = (iso: string): string => dateTimeFormatter.format(new Date(iso));
