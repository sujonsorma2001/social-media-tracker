import { FieldPath, type QueryDocumentSnapshot } from "firebase-admin/firestore";
import { adminDb } from "./firebase-admin";
import type { BankCategory } from "./types";

/**
 * Posts denormalize bank name/category so the grid can filter by category without joins.
 * When an admin edits those fields, push the change to existing posts (400 per batch).
 */
export async function propagateBankToPosts(
  bankId: string,
  fields: { bank_name: string; bank_short_name: string | null; bank_category: BankCategory },
): Promise<number> {
  const db = adminDb();
  const PAGE = 400;
  let updated = 0;
  let cursor: QueryDocumentSnapshot | undefined;

  for (;;) {
    let query = db.collection("posts").where("bank_id", "==", bankId).orderBy(FieldPath.documentId()).limit(PAGE);
    if (cursor) query = query.startAfter(cursor);
    const snap = await query.get();
    if (snap.empty) break;

    const batch = db.batch();
    snap.docs.forEach((doc) => batch.update(doc.ref, fields));
    await batch.commit();

    updated += snap.size;
    cursor = snap.docs[snap.docs.length - 1];
    if (snap.size < PAGE) break;
  }
  return updated;
}
