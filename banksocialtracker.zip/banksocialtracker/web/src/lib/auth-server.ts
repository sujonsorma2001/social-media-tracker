import type { DecodedIdToken } from "firebase-admin/auth";
import { ApiError } from "./api";
import { adminAuth } from "./firebase-admin";

const parseList = (value: string | undefined): string[] =>
  (value ?? "")
    .split(",")
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);

const adminEmails = (): string[] => parseList(process.env.ADMIN_EMAILS);

function isAllowed(email: string | undefined): boolean {
  const rules = [...parseList(process.env.ALLOWED_EMAILS), ...adminEmails()];
  if (rules.length === 0) return true; // open to any signed-in user — configure ALLOWED_EMAILS in production
  if (!email) return false;
  const e = email.toLowerCase();
  return rules.some((rule) => (rule.startsWith("@") ? e.endsWith(rule) : e === rule));
}

/** Verifies the Firebase ID token in `Authorization: Bearer <token>` and the email allow-list. */
export async function requireUser(req: Request): Promise<DecodedIdToken> {
  const header = req.headers.get("authorization");
  const token = header?.startsWith("Bearer ") ? header.slice(7).trim() : "";
  if (!token) throw new ApiError(401, "Sign in required");

  let decoded: DecodedIdToken;
  try {
    decoded = await adminAuth().verifyIdToken(token);
  } catch {
    throw new ApiError(401, "Your session expired. Sign in again.");
  }
  if (!isAllowed(decoded.email)) throw new ApiError(403, "This account is not allowed to use the tracker");
  return decoded;
}

export async function requireAdmin(req: Request): Promise<DecodedIdToken> {
  const user = await requireUser(req);
  const email = user.email?.toLowerCase();
  if (!email || !user.email_verified || !adminEmails().includes(email)) {
    throw new ApiError(403, "Admin access required (verified email listed in ADMIN_EMAILS)");
  }
  return user;
}
