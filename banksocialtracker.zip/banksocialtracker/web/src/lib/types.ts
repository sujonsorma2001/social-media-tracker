export const BANK_CATEGORIES = ["state-owned", "private", "islamic", "foreign", "specialized"] as const;
export type BankCategory = (typeof BANK_CATEGORIES)[number];

export const CATEGORY_LABELS: Record<BankCategory, string> = {
  "state-owned": "State-owned",
  private: "Private commercial",
  islamic: "Islamic",
  foreign: "Foreign",
  specialized: "Specialized",
};

/** Fields every signed-in user may see. */
export interface BankSummary {
  id: string;
  name: string;
  short_name: string | null;
  category: BankCategory;
  facebook_url: string;
}

/** Full bank record (admin only). Timestamps are ISO strings on the wire. */
export interface Bank extends BankSummary {
  facebook_handle: string;
  is_active: boolean;
  last_fetched_at: string | null;
  last_fetch_status: "ok" | "error" | null;
  last_error: string | null;
  created_at: string | null;
  updated_at: string | null;
}

export interface MediaItem {
  kind: "image" | "video";
  url: string;
  original_url: string;
  video_url: string | null;
  cached: boolean;
}

export interface Post {
  id: string;
  bank_id: string;
  bank_name: string;
  bank_short_name: string | null;
  bank_category: BankCategory;
  fb_post_id: string;
  permalink: string;
  caption: string;
  post_date: string;
  posted_at: string;
  media_type: "photo" | "video" | "album" | "text";
  media: MediaItem[];
  reactions_count: number;
  comments_count: number;
  shares_count: number;
}

export interface Campaign {
  id: string;
  name: string;
  name_bn: string | null;
  /** `YYYY-MM-DD` keys (Asia/Dhaka). A festival can span several days. */
  dates: string[];
  color: string;
  description: string | null;
  is_active: boolean;
}

export interface PostsResponse {
  posts: Post[];
  count: number;
  banks_with_posts: number;
  /** True when more than the server's hard read cap matched. */
  truncated: boolean;
}
