"use client";

import { useMemo, useState } from "react";
import { CalendarDays } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatDateShort, keyToLocalDate, localDateToKey, todayInDhaka } from "@/lib/date";
import type { Campaign } from "@/lib/types";

interface CalendarFilterProps {
  value: Date;
  onChange: (date: Date) => void;
  /** Festival/campaign dates are highlighted and offered as one-click shortcuts. */
  campaigns: Campaign[];
}

export function CalendarFilter({ value, onChange, campaigns }: CalendarFilterProps) {
  const [month, setMonth] = useState<Date>(value);
  // "Today" is Dhaka's today, not the viewer's, so posts can never be requested for a future Dhaka day.
  const today = useMemo(() => keyToLocalDate(todayInDhaka()), []);
  const selectedKey = localDateToKey(value);

  const shortcuts = useMemo(
    () =>
      campaigns
        .flatMap((c) =>
          c.dates.map((dateKey) => ({
            id: `${c.id}:${dateKey}`,
            label: c.dates.length > 1 ? `${c.name} · ${formatDateShort(dateKey)}` : c.name,
            dateKey,
          })),
        )
        .sort((a, b) => b.dateKey.localeCompare(a.dateKey))
        .slice(0, 12),
    [campaigns],
  );
  const campaignDates = useMemo(() => shortcuts.map((s) => keyToLocalDate(s.dateKey)), [shortcuts]);

  const select = (date: Date) => {
    onChange(date);
    setMonth(date);
  };

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-base">
          <CalendarDays className="size-4" aria-hidden />
          Pick a day
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Calendar
          mode="single"
          selected={value}
          onSelect={(date) => date && select(date)}
          month={month}
          onMonthChange={setMonth}
          disabled={{ after: today }}
          modifiers={{ campaign: campaignDates }}
          modifiersClassNames={{ campaign: "font-bold underline decoration-2 underline-offset-4" }}
          className="mx-auto p-0"
        />
        <Button variant="outline" size="sm" className="w-full" onClick={() => select(today)}>
          Jump to today
        </Button>

        {shortcuts.length > 0 && (
          <div>
            <p className="mb-2 text-xs text-muted-foreground">Festivals &amp; campaigns (underlined above)</p>
            <div className="flex flex-wrap gap-1.5">
              {shortcuts.map((s) => (
                <Button
                  key={s.id}
                  size="sm"
                  variant={s.dateKey === selectedKey ? "default" : "secondary"}
                  className="h-7 px-2.5 text-xs"
                  onClick={() => select(keyToLocalDate(s.dateKey))}
                >
                  {s.label}
                </Button>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
