"use client";

import type { ReactNode } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut } from "firebase/auth";
import { LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AuthGate, useAuth } from "@/components/auth-provider";
import { auth } from "@/lib/firebase";
import { cn } from "@/lib/utils";

const NAV = [
  { href: "/", label: "Posts by date" },
  { href: "/admin/banks", label: "Banks" },
  { href: "/admin/campaigns", label: "Campaigns" },
] as const;

function Header() {
  const pathname = usePathname();
  const { user } = useAuth();
  return (
    <header className="sticky top-0 z-30 border-b bg-background/95 backdrop-blur">
      <div className="mx-auto flex h-14 max-w-7xl items-center gap-6 px-4 md:px-6">
        <Link href="/" className="font-semibold tracking-tight">
          BankSocialTracker
        </Link>
        <nav className="flex flex-1 items-center gap-1" aria-label="Main">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              aria-current={pathname === item.href ? "page" : undefined}
              className={cn(
                "rounded-md px-3 py-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground",
                pathname === item.href && "bg-muted font-medium text-foreground",
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <span className="hidden text-sm text-muted-foreground sm:inline">{user?.email}</span>
        <Button variant="ghost" size="sm" onClick={() => void signOut(auth)}>
          <LogOut className="mr-2 size-4" />
          Sign out
        </Button>
      </div>
    </header>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <AuthGate>
      <Header />
      <main className="mx-auto max-w-7xl px-4 py-6 md:px-6">{children}</main>
    </AuthGate>
  );
}
