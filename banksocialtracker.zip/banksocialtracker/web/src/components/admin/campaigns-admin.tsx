"use client";

import { useState, type FormEvent } from "react";
import { Loader2, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useApi } from "@/hooks/use-api";
import { apiFetch } from "@/lib/api-client";
import { formatDateShort } from "@/lib/date";
import type { Campaign } from "@/lib/types";

export function CampaignsAdmin() {
  const { data, error, reload } = useApi<{ campaigns: Campaign[] }>("/api/campaigns");
  const [name, setName] = useState("");
  const [dates, setDates] = useState("");
  const [color, setColor] = useState("#16a34a");
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  async function create(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    setFormError(null);
    try {
      // Accept commas, spaces or new lines between dates.
      const list = dates.split(/[\s,]+/).filter(Boolean);
      await apiFetch("/api/admin/campaigns", { method: "POST", body: JSON.stringify({ name, dates: list, color }) });
      setName("");
      setDates("");
      reload();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Could not create the campaign");
    } finally {
      setSaving(false);
    }
  }

  async function remove(campaign: Campaign) {
    if (!window.confirm(`Delete "${campaign.name}"? Posts are not affected.`)) return;
    try {
      await apiFetch(`/api/admin/campaigns/${campaign.id}`, { method: "DELETE" });
      reload();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Could not delete the campaign");
    }
  }

  return (
    <div className="grid gap-6 md:grid-cols-[360px_1fr]">
      <Card>
        <CardHeader>
          <CardTitle className="text-base">New campaign or festival</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={create} className="space-y-3">
            <div className="space-y-2">
              <Label htmlFor="c-name">Name</Label>
              <Input id="c-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Eid-ul-Fitr" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="c-dates">Dates (YYYY-MM-DD)</Label>
              <Input id="c-dates" value={dates} onChange={(e) => setDates(e.target.value)} placeholder="2026-03-21, 2026-03-22" required />
              <p className="text-xs text-muted-foreground">Separate several days with commas.</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="c-color">Color</Label>
              <Input id="c-color" type="color" value={color} onChange={(e) => setColor(e.target.value)} className="h-9 w-16 p-1" />
            </div>
            {formError && (
              <p role="alert" className="text-sm text-destructive">
                {formError}
              </p>
            )}
            <Button type="submit" disabled={saving}>
              {saving && <Loader2 className="mr-2 size-4 animate-spin" aria-hidden />}
              Add campaign
            </Button>
          </form>
        </CardContent>
      </Card>

      <div className="space-y-3">
        <h1 className="text-2xl font-semibold tracking-tight">Campaigns</h1>
        {error && <p className="text-sm text-destructive">{error}</p>}
        {data?.campaigns.length === 0 && <p className="text-sm text-muted-foreground">No campaigns yet.</p>}
        <ul className="space-y-2">
          {data?.campaigns.map((c) => (
            <li key={c.id} className="flex items-center gap-3 rounded-lg border p-3">
              <span className="size-3 shrink-0 rounded-full" style={{ backgroundColor: c.color }} aria-hidden />
              <div className="min-w-0 flex-1">
                <p className="font-medium">{c.name}</p>
                <p className="text-xs text-muted-foreground">{c.dates.map(formatDateShort).join(", ")}</p>
              </div>
              <Button variant="ghost" size="icon" onClick={() => void remove(c)} aria-label={`Delete ${c.name}`}>
                <Trash2 className="size-4" />
              </Button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
