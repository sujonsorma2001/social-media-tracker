"use client";

import { useEffect, useState } from "react";
import { ExternalLink, Pencil, Plus } from "lucide-react";
import { BankFormDialog } from "@/components/admin/bank-form-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useApi } from "@/hooks/use-api";
import { apiFetch } from "@/lib/api-client";
import { formatDhakaDateTime } from "@/lib/date";
import { CATEGORY_LABELS, type Bank } from "@/lib/types";

function SyncStatus({ bank }: { bank: Bank }) {
  if (!bank.last_fetched_at) return <span className="text-sm text-muted-foreground">Never fetched</span>;
  return (
    <div className="flex flex-col gap-0.5">
      <Badge variant={bank.last_fetch_status === "error" ? "destructive" : "secondary"} className="w-fit" title={bank.last_error ?? undefined}>
        {bank.last_fetch_status === "error" ? "Failed" : "OK"}
      </Badge>
      <span className="text-xs text-muted-foreground">{formatDhakaDateTime(bank.last_fetched_at)}</span>
    </div>
  );
}

export function BanksAdmin() {
  const { data, error, loading, reload } = useApi<{ banks: Bank[] }>("/api/admin/banks");
  const [rows, setRows] = useState<Bank[]>([]);
  const [editing, setEditing] = useState<Bank | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  useEffect(() => {
    if (data) setRows(data.banks);
  }, [data]);

  const setActive = (id: string, value: boolean) => setRows((r) => r.map((b) => (b.id === id ? { ...b, is_active: value } : b)));

  /** Optimistic toggle with rollback if the server rejects it. */
  async function toggle(bank: Bank, next: boolean) {
    setActionError(null);
    setActive(bank.id, next);
    try {
      await apiFetch(`/api/admin/banks/${bank.id}`, { method: "PATCH", body: JSON.stringify({ is_active: next }) });
    } catch (err) {
      setActive(bank.id, !next);
      setActionError(err instanceof Error ? err.message : "Could not update the bank");
    }
  }

  const activeCount = rows.filter((b) => b.is_active).length;

  return (
    <div className="space-y-4">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Bank pages</h1>
          <p className="text-sm text-muted-foreground">
            {rows.length > 0 ? `${activeCount} of ${rows.length} active. Only active pages are fetched.` : "Pages the scheduled job fetches posts from."}
          </p>
        </div>
        <Button
          onClick={() => {
            setEditing(null);
            setDialogOpen(true);
          }}
        >
          <Plus className="mr-2 size-4" aria-hidden />
          Add bank
        </Button>
      </div>

      {(error || actionError) && (
        <p role="alert" className="rounded-md border border-destructive/30 px-3 py-2 text-sm text-destructive">
          {actionError ?? error}
        </p>
      )}

      <div className="rounded-xl border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Bank</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>Facebook page</TableHead>
              <TableHead>Last fetch</TableHead>
              <TableHead className="text-center">Active</TableHead>
              <TableHead className="w-12" />
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading && rows.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} className="py-10 text-center text-muted-foreground">
                  Loading…
                </TableCell>
              </TableRow>
            )}
            {!loading && !error && rows.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} className="py-10 text-center text-muted-foreground">
                  No banks yet. Add the first one.
                </TableCell>
              </TableRow>
            )}
            {rows.map((bank) => (
              <TableRow key={bank.id} className={bank.is_active ? "" : "opacity-60"}>
                <TableCell className="font-medium">
                  {bank.name}
                  {bank.short_name && <span className="ml-2 text-xs text-muted-foreground">{bank.short_name}</span>}
                </TableCell>
                <TableCell>{CATEGORY_LABELS[bank.category] ?? bank.category}</TableCell>
                <TableCell>
                  <a
                    href={bank.facebook_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-sm hover:underline"
                  >
                    {bank.facebook_handle}
                    <ExternalLink className="size-3" aria-hidden />
                  </a>
                </TableCell>
                <TableCell>
                  <SyncStatus bank={bank} />
                </TableCell>
                <TableCell className="text-center">
                  <Switch checked={bank.is_active} onCheckedChange={(v) => void toggle(bank, v)} aria-label={`Fetch posts for ${bank.name}`} />
                </TableCell>
                <TableCell>
                  <Button
                    variant="ghost"
                    size="icon"
                    aria-label={`Edit ${bank.name}`}
                    onClick={() => {
                      setEditing(bank);
                      setDialogOpen(true);
                    }}
                  >
                    <Pencil className="size-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <BankFormDialog open={dialogOpen} onOpenChange={setDialogOpen} bank={editing} onSaved={reload} />
    </div>
  );
}
