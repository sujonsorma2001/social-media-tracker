"use client";

import { useEffect, useState, type FormEvent } from "react";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiFetch } from "@/lib/api-client";
import { BANK_CATEGORIES, CATEGORY_LABELS, type Bank, type BankCategory } from "@/lib/types";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** `null` = create a new bank. */
  bank: Bank | null;
  onSaved: () => void;
}

export function BankFormDialog({ open, onOpenChange, bank, onSaved }: Props) {
  const [name, setName] = useState("");
  const [shortName, setShortName] = useState("");
  const [category, setCategory] = useState<BankCategory>("private");
  const [url, setUrl] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Reset the form each time the dialog opens.
  useEffect(() => {
    if (!open) return;
    setName(bank?.name ?? "");
    setShortName(bank?.short_name ?? "");
    setCategory(bank?.category ?? "private");
    setUrl(bank?.facebook_url ?? "");
    setError(null);
  }, [open, bank]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    try {
      const body = JSON.stringify({ name, short_name: shortName, category, facebook_url: url });
      if (bank) await apiFetch(`/api/admin/banks/${bank.id}`, { method: "PATCH", body });
      else await apiFetch("/api/admin/banks", { method: "POST", body });
      onSaved();
      onOpenChange(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save the bank");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <form onSubmit={submit} className="space-y-4">
          <DialogHeader>
            <DialogTitle>{bank ? "Edit bank" : "Add bank"}</DialogTitle>
            <DialogDescription>The Facebook page must be public. Posts are fetched on the next scheduled run.</DialogDescription>
          </DialogHeader>

          <div className="space-y-2">
            <Label htmlFor="bank-name">Bank name</Label>
            <Input id="bank-name" value={name} onChange={(e) => setName(e.target.value)} required minLength={2} maxLength={120} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="bank-short">Short name</Label>
              <Input id="bank-short" value={shortName} onChange={(e) => setShortName(e.target.value)} maxLength={30} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="bank-category">Category</Label>
              <Select value={category} onValueChange={(v) => setCategory(v as BankCategory)}>
                <SelectTrigger id="bank-category">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {BANK_CATEGORIES.map((c) => (
                    <SelectItem key={c} value={c}>
                      {CATEGORY_LABELS[c]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="bank-url">Facebook page URL</Label>
            <Input
              id="bank-url"
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://www.facebook.com/yourbank"
              required
            />
          </div>

          {error && (
            <p role="alert" className="text-sm text-destructive">
              {error}
            </p>
          )}

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving && <Loader2 className="mr-2 size-4 animate-spin" aria-hidden />}
              {bank ? "Save changes" : "Add bank"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
