"use client";

import { AlertTriangle, Inbox } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { PostCard } from "@/components/post-card";
import type { Post } from "@/lib/types";

interface PostGridProps {
  posts: Post[];
  loading: boolean;
  error: string | null;
  onRetry: () => void;
  /** Shown in the empty state, e.g. "Saturday, 14 April 2026". */
  dateLabel: string;
  hasActiveFilters: boolean;
}

export function PostGrid({ posts, loading, error, onRetry, dateLabel, hasActiveFilters }: PostGridProps) {
  if (loading) {
    return (
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3" aria-busy="true" aria-label="Loading posts">
        {Array.from({ length: 6 }, (_, i) => (
          <Skeleton key={i} className="h-96 rounded-xl" />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div role="alert" className="flex flex-col items-center gap-3 rounded-xl border border-destructive/30 p-10 text-center">
        <AlertTriangle className="size-6 text-destructive" aria-hidden />
        <p className="text-sm">{error}</p>
        <Button variant="outline" size="sm" onClick={onRetry}>
          Try again
        </Button>
      </div>
    );
  }

  if (posts.length === 0) {
    return (
      <div className="flex flex-col items-center gap-2 rounded-xl border border-dashed p-12 text-center">
        <Inbox className="size-6 text-muted-foreground" aria-hidden />
        <p className="font-medium">No posts found for {dateLabel}</p>
        <p className="max-w-sm text-sm text-muted-foreground">
          {hasActiveFilters
            ? "Clear the bank, category or search filters to widen the results."
            : "Posts appear after the next scheduled fetch. For older days, run the “Fetch bank posts” workflow with a larger lookback."}
        </p>
      </div>
    );
  }

  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
      {posts.map((post) => (
        <PostCard key={post.id} post={post} />
      ))}
    </div>
  );
}
