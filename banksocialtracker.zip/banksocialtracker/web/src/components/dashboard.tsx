"use client";

import { useState } from "react";
import { AlertTriangle } from "lucide-react";
import { CalendarFilter } from "@/components/calendar-filter";
import { ALL, FilterBar } from "@/components/filter-bar";
import { PostGrid } from "@/components/post-grid";
import { useApi } from "@/hooks/use-api";
import { useDebouncedValue } from "@/hooks/use-debounced-value";
import { formatDateLong, keyToLocalDate, localDateToKey, todayInDhaka } from "@/lib/date";
import type { BankSummary, Campaign, PostsResponse } from "@/lib/types";

export function Dashboard() {
  const [date, setDate] = useState<Date>(() => keyToLocalDate(todayInDhaka()));
  const [bankId, setBankId] = useState(ALL);
  const [category, setCategory] = useState(ALL);
  const [search, setSearch] = useState("");
  const debouncedSearch = useDebouncedValue(search.trim(), 300);

  const dateKey = localDateToKey(date);

  const params = new URLSearchParams({ date: dateKey });
  if (bankId !== ALL) params.set("bank_id", bankId);
  else if (category !== ALL) params.set("category", category);
  if (debouncedSearch) params.set("q", debouncedSearch);

  const posts = useApi<PostsResponse>(`/api/posts?${params.toString()}`);
  const banks = useApi<{ banks: BankSummary[] }>("/api/banks");
  const campaigns = useApi<{ campaigns: Campaign[] }>("/api/campaigns");

  const handleCategory = (value: string) => {
    setCategory(value);
    setBankId(ALL); // a previously chosen bank may not belong to the new category
  };

  const data = posts.data;
  const hasActiveFilters = bankId !== ALL || category !== ALL || debouncedSearch !== "";
  const dateLabel = formatDateLong(dateKey);

  return (
    <div className="grid gap-6 lg:grid-cols-[320px_1fr]">
      <aside className="lg:sticky lg:top-20 lg:self-start">
        <CalendarFilter value={date} onChange={setDate} campaigns={campaigns.data?.campaigns ?? []} />
      </aside>

      <section className="min-w-0 space-y-4" aria-live="polite">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">{dateLabel}</h1>
          <p className="text-sm text-muted-foreground">
            {data && !posts.loading
              ? `${data.count} post${data.count === 1 ? "" : "s"} from ${data.banks_with_posts} bank${data.banks_with_posts === 1 ? "" : "s"}`
              : "Loading…"}
            {" · Asia/Dhaka time"}
          </p>
        </div>

        <FilterBar
          banks={banks.data?.banks ?? []}
          bankId={bankId}
          category={category}
          search={search}
          onBankChange={setBankId}
          onCategoryChange={handleCategory}
          onSearchChange={setSearch}
        />

        {data?.truncated && !posts.loading && (
          <p className="flex items-center gap-2 rounded-md border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-sm">
            <AlertTriangle className="size-4" aria-hidden />
            Showing the first 1,000 posts for this day. Narrow by bank or category to see the rest.
          </p>
        )}

        <PostGrid
          posts={data?.posts ?? []}
          loading={posts.loading}
          error={posts.error}
          onRetry={posts.reload}
          dateLabel={dateLabel}
          hasActiveFilters={hasActiveFilters}
        />
      </section>
    </div>
  );
}
