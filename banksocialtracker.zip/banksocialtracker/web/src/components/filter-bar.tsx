"use client";

import { Search, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BANK_CATEGORIES, CATEGORY_LABELS, type BankSummary } from "@/lib/types";

/** Radix Select forbids empty-string values, so "no filter" is a sentinel. */
export const ALL = "all";

interface FilterBarProps {
  banks: BankSummary[];
  bankId: string;
  category: string;
  search: string;
  onBankChange: (value: string) => void;
  onCategoryChange: (value: string) => void;
  onSearchChange: (value: string) => void;
}

export function FilterBar({ banks, bankId, category, search, onBankChange, onCategoryChange, onSearchChange }: FilterBarProps) {
  const visibleBanks = category === ALL ? banks : banks.filter((b) => b.category === category);

  return (
    <div className="grid gap-3 md:grid-cols-[1fr_220px_240px]">
      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
        <Input
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="Search captions (Bengali or English)"
          aria-label="Search captions"
          className="pl-9 pr-9"
        />
        {search && (
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-1 top-1/2 size-7 -translate-y-1/2"
            onClick={() => onSearchChange("")}
            aria-label="Clear search"
          >
            <X className="size-4" />
          </Button>
        )}
      </div>

      <Select value={category} onValueChange={onCategoryChange}>
        <SelectTrigger aria-label="Filter by category">
          <SelectValue placeholder="All categories" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value={ALL}>All categories</SelectItem>
          {BANK_CATEGORIES.map((c) => (
            <SelectItem key={c} value={c}>
              {CATEGORY_LABELS[c]}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Select value={bankId} onValueChange={onBankChange}>
        <SelectTrigger aria-label="Filter by bank">
          <SelectValue placeholder="All banks" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value={ALL}>All banks</SelectItem>
          {visibleBanks.map((b) => (
            <SelectItem key={b.id} value={b.id}>
              {b.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
