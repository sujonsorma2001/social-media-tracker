"use client";

import { memo, useState } from "react";
import { ExternalLink, Heart, ImageOff, Images, MessageCircle, Play, Share2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { formatDhakaTime } from "@/lib/date";
import { CATEGORY_LABELS, type Post } from "@/lib/types";

const compact = new Intl.NumberFormat("en", { notation: "compact", maximumFractionDigits: 1 });
const CAPTION_PREVIEW_CHARS = 220;

function Stat({ icon: Icon, value, label }: { icon: typeof Heart; value: number; label: string }) {
  return (
    <span className="inline-flex items-center gap-1" title={`${value.toLocaleString("en")} ${label}`}>
      <Icon className="size-4" aria-hidden />
      <span aria-label={`${value} ${label}`}>{compact.format(value)}</span>
    </span>
  );
}

function PostMedia({ post }: { post: Post }) {
  const [broken, setBroken] = useState(false);
  const cover = post.media[0];
  const isVideo = post.media_type === "video";

  // Text-only posts have no media block; media-less video/photo posts fall back to a placeholder.
  if (!cover && post.media_type === "text") return null;

  return (
    <a
      href={post.permalink}
      target="_blank"
      rel="noopener noreferrer"
      className="group relative block aspect-[4/3] overflow-hidden bg-muted"
      aria-label={`Open ${isVideo ? "video" : "post"} on Facebook`}
    >
      {cover && !broken ? (
        // eslint-disable-next-line @next/next/no-img-element -- remote Facebook/Storage URLs; avoids image-optimizer quota
        <img
          src={cover.url}
          alt={`${post.bank_name} post preview`}
          loading="lazy"
          referrerPolicy="no-referrer"
          onError={() => setBroken(true)}
          className="size-full object-cover transition-transform duration-300 group-hover:scale-[1.02]"
        />
      ) : (
        <div className="flex size-full flex-col items-center justify-center gap-1 text-sm text-muted-foreground">
          <ImageOff className="size-6" aria-hidden />
          Preview unavailable. Open on Facebook.
        </div>
      )}
      {isVideo && !broken && (
        <span className="absolute inset-0 flex items-center justify-center bg-black/10">
          <span className="rounded-full bg-black/60 p-3 text-white">
            <Play className="size-5 fill-current" aria-hidden />
          </span>
        </span>
      )}
      {post.media.length > 1 && (
        <Badge variant="secondary" className="absolute right-2 top-2 gap-1">
          <Images className="size-3" aria-hidden />
          {post.media.length}
        </Badge>
      )}
    </a>
  );
}

function PostCardImpl({ post }: { post: Post }) {
  const [expanded, setExpanded] = useState(false);
  const long = post.caption.length > CAPTION_PREVIEW_CHARS;

  return (
    <Card className="flex flex-col overflow-hidden pt-0">
      <PostMedia post={post} />

      <CardHeader className="gap-1 pt-4">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-semibold leading-tight">{post.bank_name}</h3>
          <time dateTime={post.posted_at} className="shrink-0 text-xs text-muted-foreground">
            {formatDhakaTime(post.posted_at)}
          </time>
        </div>
        <Badge variant="outline" className="w-fit text-xs font-normal">
          {CATEGORY_LABELS[post.bank_category] ?? post.bank_category}
        </Badge>
      </CardHeader>

      <CardContent className="flex-1">
        {post.caption ? (
          <>
            <p className={`whitespace-pre-line break-words text-sm leading-relaxed ${expanded ? "" : "line-clamp-4"}`}>{post.caption}</p>
            {long && (
              <button
                type="button"
                onClick={() => setExpanded((v) => !v)}
                className="mt-1 text-xs font-medium text-primary hover:underline"
                aria-expanded={expanded}
              >
                {expanded ? "Show less" : "Show more"}
              </button>
            )}
          </>
        ) : (
          <p className="text-sm italic text-muted-foreground">No caption</p>
        )}
      </CardContent>

      <CardFooter className="flex items-center justify-between gap-2 border-t pt-4">
        <div className="flex items-center gap-3 text-sm text-muted-foreground">
          <Stat icon={Heart} value={post.reactions_count} label="reactions" />
          <Stat icon={MessageCircle} value={post.comments_count} label="comments" />
          <Stat icon={Share2} value={post.shares_count} label="shares" />
        </div>
        <Button asChild size="sm" variant="outline">
          <a href={post.permalink} target="_blank" rel="noopener noreferrer">
            Facebook
            <ExternalLink className="ml-1.5 size-3.5" aria-hidden />
          </a>
        </Button>
      </CardFooter>
    </Card>
  );
}

export const PostCard = memo(PostCardImpl);
