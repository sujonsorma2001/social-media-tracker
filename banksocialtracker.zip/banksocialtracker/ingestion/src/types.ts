export type BankCategory = "state-owned" | "private" | "islamic" | "foreign" | "specialized";
export type MediaType = "photo" | "video" | "album" | "text";

/** Subset of the `banks/{id}` document the ingestion job needs. */
export interface BankDoc {
  id: string;
  name: string;
  short_name: string | null;
  category: BankCategory;
  facebook_url: string;
  facebook_handle: string;
}

/** Provider-agnostic media shape. */
export interface RawMedia {
  kind: "image" | "video";
  /** Displayable image (photo, or poster frame for videos). */
  imageUrl: string | null;
  videoUrl: string | null;
}

/** Provider-agnostic post shape. Every provider must map into this. */
export interface RawPost {
  fbPostId: string;
  permalink: string;
  caption: string;
  postedAt: Date;
  media: RawMedia[];
  reactionsCount: number;
  commentsCount: number;
  sharesCount: number;
}

export interface MediaItem {
  kind: "image" | "video";
  /** URL the UI renders: our Storage copy when cached, otherwise the (expiring) Facebook CDN URL. */
  url: string;
  original_url: string;
  /** Direct video URL. Expires quickly, so the UI links to Facebook for playback instead. */
  video_url: string | null;
  cached: boolean;
}

export interface PostDoc {
  id: string;
  bank_id: string;
  bank_name: string;
  bank_short_name: string | null;
  bank_category: BankCategory;
  fb_post_id: string;
  permalink: string;
  caption: string;
  /** `YYYY-MM-DD` in Asia/Dhaka. */
  post_date: string;
  posted_at: Date;
  media_type: MediaType;
  media: MediaItem[];
  reactions_count: number;
  comments_count: number;
  shares_count: number;
  source: string;
}
