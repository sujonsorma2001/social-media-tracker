import { toDhakaDateKey } from "./date";
import type { BankDoc, MediaItem, MediaType, PostDoc, RawPost } from "./types";

const MAX_MEDIA_PER_POST = 6;

/** Firestore document IDs cannot contain "/" and should stay short. */
const safeId = (value: string): string => value.replace(/[^A-Za-z0-9_.-]/g, "_").slice(0, 120);

/**
 * Maps a provider post into the Firestore `posts` shape.
 * The document ID is deterministic (bank + Facebook post ID), which makes upserts idempotent.
 */
export function buildPostDoc(bank: BankDoc, raw: RawPost, source: string): PostDoc {
  const media: MediaItem[] = raw.media
    .filter((m): m is typeof m & { imageUrl: string } => m.imageUrl !== null)
    .slice(0, MAX_MEDIA_PER_POST)
    .map((m) => ({
      kind: m.kind,
      url: m.imageUrl,
      original_url: m.imageUrl,
      video_url: m.videoUrl,
      cached: false,
    }));

  const hasVideo = raw.media.some((m) => m.kind === "video");
  const mediaType: MediaType = hasVideo ? "video" : raw.media.length > 1 ? "album" : raw.media.length === 1 ? "photo" : "text";

  return {
    id: `${bank.id}_${safeId(raw.fbPostId)}`,
    bank_id: bank.id,
    bank_name: bank.name,
    bank_short_name: bank.short_name,
    bank_category: bank.category,
    fb_post_id: raw.fbPostId,
    permalink: raw.permalink,
    caption: raw.caption,
    post_date: toDhakaDateKey(raw.postedAt),
    posted_at: raw.postedAt,
    media_type: mediaType,
    media,
    reactions_count: raw.reactionsCount,
    comments_count: raw.commentsCount,
    shares_count: raw.sharesCount,
    source,
  };
}
