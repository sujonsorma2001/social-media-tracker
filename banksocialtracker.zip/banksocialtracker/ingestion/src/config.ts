import type { ServiceAccount } from "firebase-admin/app";

export interface Config {
  serviceAccount: ServiceAccount;
  storageBucket: string | null;
  apifyToken: string;
  provider: "apify";
  /** Posts older than now - lookbackHours are ignored. Also refreshes engagement counts inside the window. */
  lookbackHours: number;
  maxPostsPerBank: number;
  concurrency: number;
  cacheMedia: boolean;
  onlyBankId: string | null;
}

function env(name: string): string | undefined {
  const value = process.env[name]?.trim();
  return value ? value : undefined;
}

function requireEnv(name: string): string {
  const value = env(name);
  if (!value) throw new Error(`Missing required environment variable: ${name}`);
  return value;
}

function intEnv(name: string, fallback: number, min: number, max: number): number {
  const raw = env(name);
  if (raw === undefined) return fallback;
  const n = Number(raw);
  if (!Number.isInteger(n) || n < min || n > max) {
    throw new Error(`${name} must be an integer between ${min} and ${max} (got "${raw}")`);
  }
  return n;
}

/** Accepts raw JSON or base64-encoded JSON (handy for secret stores that mangle newlines). */
function parseServiceAccount(raw: string): ServiceAccount {
  const json = raw.startsWith("{") ? raw : Buffer.from(raw, "base64").toString("utf8");
  try {
    const parsed: unknown = JSON.parse(json);
    if (typeof parsed !== "object" || parsed === null) throw new Error("not an object");
    return parsed as ServiceAccount;
  } catch (err) {
    throw new Error(`FIREBASE_SERVICE_ACCOUNT is not valid JSON/base64 JSON: ${(err as Error).message}`);
  }
}

export function loadConfig(): Config {
  const cacheMedia = (env("CACHE_MEDIA") ?? "true").toLowerCase() === "true";
  const storageBucket = env("FIREBASE_STORAGE_BUCKET") ?? null;
  if (cacheMedia && !storageBucket) {
    throw new Error("CACHE_MEDIA=true requires FIREBASE_STORAGE_BUCKET (or set CACHE_MEDIA=false)");
  }
  return {
    serviceAccount: parseServiceAccount(requireEnv("FIREBASE_SERVICE_ACCOUNT")),
    storageBucket,
    apifyToken: requireEnv("APIFY_TOKEN"),
    provider: "apify",
    lookbackHours: intEnv("LOOKBACK_HOURS", 48, 1, 24 * 365),
    maxPostsPerBank: intEnv("MAX_POSTS_PER_BANK", 25, 1, 400), // Firestore batch limit is 500 writes
    concurrency: intEnv("CONCURRENCY", 4, 1, 16),
    cacheMedia,
    onlyBankId: env("ONLY_BANK_ID") ?? null,
  };
}
