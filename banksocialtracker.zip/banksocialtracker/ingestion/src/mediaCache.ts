import { randomUUID } from "node:crypto";
import type { Bucket } from "./firebase";

const MAX_BYTES = 15 * 1024 * 1024;
const EXTENSIONS: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/gif": "gif",
};

function downloadUrl(bucketName: string, objectPath: string, token: string): string {
  return `https://firebasestorage.googleapis.com/v0/b/${bucketName}/o/${encodeURIComponent(objectPath)}?alt=media&token=${token}`;
}

/**
 * Copies an image from Facebook's CDN into Firebase Storage. Facebook CDN URLs are signed
 * and expire within days, so uncached previews eventually break.
 * Returns a long-lived download URL, or null if the image could not be cached.
 * Idempotent: an existing object is reused instead of downloaded again.
 */
export async function cacheImage(bucket: Bucket, basePath: string, sourceUrl: string): Promise<string | null> {
  try {
    for (const ext of Object.values(EXTENSIONS)) {
      const existing = bucket.file(`${basePath}.${ext}`);
      const [exists] = await existing.exists();
      if (exists) {
        const [meta] = await existing.getMetadata();
        const token = String(meta.metadata?.firebaseStorageDownloadTokens ?? "").split(",")[0];
        if (token) return downloadUrl(bucket.name, existing.name, token);
      }
    }

    const res = await fetch(sourceUrl, { signal: AbortSignal.timeout(20_000) });
    if (!res.ok) return null;
    const contentType = (res.headers.get("content-type") ?? "").split(";")[0]?.trim().toLowerCase() ?? "";
    const ext = EXTENSIONS[contentType];
    if (!ext) return null;

    const bytes = Buffer.from(await res.arrayBuffer());
    if (bytes.length === 0 || bytes.length > MAX_BYTES) return null;

    const token = randomUUID();
    const file = bucket.file(`${basePath}.${ext}`);
    await file.save(bytes, {
      contentType,
      resumable: false,
      metadata: {
        cacheControl: "public, max-age=31536000, immutable",
        metadata: { firebaseStorageDownloadTokens: token },
      },
    });
    return downloadUrl(bucket.name, file.name, token);
  } catch {
    return null; // Caching is best-effort; the direct URL remains as a fallback.
  }
}
