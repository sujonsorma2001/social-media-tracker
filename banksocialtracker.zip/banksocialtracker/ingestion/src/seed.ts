import { readFile } from "node:fs/promises";
import { FieldValue } from "firebase-admin/firestore";
import { loadConfig } from "./config";
import { initFirebase } from "./firebase";
import type { BankCategory } from "./types";

interface SeedBank {
  name: string;
  short_name?: string;
  category: BankCategory;
  facebook_url: string;
}

function parseFacebookUrl(input: string): { handle: string; canonicalUrl: string } | null {
  try {
    const url = new URL(input);
    if (!/(^|\.)facebook\.com$/i.test(url.hostname)) return null;
    if (url.pathname.replace(/\/+$/, "") === "/profile.php") {
      const id = url.searchParams.get("id");
      return id && /^\d+$/.test(id) ? { handle: id, canonicalUrl: `https://www.facebook.com/profile.php?id=${id}` } : null;
    }
    const handle = url.pathname.split("/").filter(Boolean)[0];
    return handle && /^[\w.-]{3,100}$/.test(handle) ? { handle, canonicalUrl: `https://www.facebook.com/${handle}` } : null;
  } catch {
    return null;
  }
}

const idFromHandle = (handle: string): string => handle.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");

async function main(): Promise<void> {
  process.env.APIFY_TOKEN ??= "unused-by-seed";
  process.env.CACHE_MEDIA = "false";
  const cfg = loadConfig();
  const { db } = initFirebase({ ...cfg, cacheMedia: false });
  const file = process.argv[2] ?? "data/banks.seed.json";
  const banks = JSON.parse(await readFile(file, "utf8")) as SeedBank[];

  let written = 0;
  for (const bank of banks) {
    const parsed = parseFacebookUrl(bank.facebook_url);
    if (!parsed || bank.facebook_url.includes("REPLACE_ME")) {
      console.warn(`Skipping "${bank.name}": replace facebook_url with the real page URL`);
      continue;
    }
    const id = idFromHandle(parsed.handle);
    await db.collection("banks").doc(id).set(
      {
        id,
        name: bank.name,
        short_name: bank.short_name ?? null,
        category: bank.category,
        facebook_url: parsed.canonicalUrl,
        facebook_handle: parsed.handle,
        is_active: true,
        last_fetched_at: null,
        last_fetch_status: null,
        last_error: null,
        updated_at: FieldValue.serverTimestamp(),
        created_at: FieldValue.serverTimestamp(),
      },
      { merge: true },
    );
    written++;
  }
  console.log(`Seeded ${written}/${banks.length} bank(s).`);
}

main().catch((err: unknown) => {
  console.error(err);
  process.exit(1);
});
