import { FieldValue, Timestamp, type Firestore } from "firebase-admin/firestore";
import { loadConfig, type Config } from "./config";
import { initFirebase, type Bucket } from "./firebase";
import { cacheImage } from "./mediaCache";
import { buildPostDoc } from "./normalize";
import { ApifyProvider } from "./providers/apify";
import type { PostProvider } from "./providers/types";
import type { BankCategory, BankDoc, MediaItem, PostDoc } from "./types";
import { errorMessage, log, runPool, withRetry } from "./util";

interface Context {
  db: Firestore;
  bucket: Bucket | null;
  provider: PostProvider;
  cfg: Config;
  since: Date;
}

interface BankResult {
  bankId: string;
  ok: boolean;
  fetched: number;
  written: number;
  error?: string;
}

const CATEGORIES: readonly BankCategory[] = ["state-owned", "private", "islamic", "foreign", "specialized"];

function parseBank(id: string, data: FirebaseFirestore.DocumentData): BankDoc | null {
  const { name, facebook_url, facebook_handle, category, short_name } = data;
  if (typeof name !== "string" || typeof facebook_url !== "string" || !CATEGORIES.includes(category)) {
    log(`Skipping bank "${id}": missing name / facebook_url / valid category`);
    return null;
  }
  return {
    id,
    name,
    short_name: typeof short_name === "string" ? short_name : null,
    category,
    facebook_url,
    facebook_handle: typeof facebook_handle === "string" ? facebook_handle : id,
  };
}

async function loadBanks(db: Firestore, onlyBankId: string | null): Promise<BankDoc[]> {
  if (onlyBankId) {
    const snap = await db.collection("banks").doc(onlyBankId).get(); // allowed even if inactive (for testing)
    const bank = snap.exists ? parseBank(snap.id, snap.data() ?? {}) : null;
    if (!bank) throw new Error(`ONLY_BANK_ID "${onlyBankId}" not found or invalid`);
    return [bank];
  }
  const snap = await db.collection("banks").where("is_active", "==", true).get();
  return snap.docs.flatMap((d) => {
    const bank = parseBank(d.id, d.data());
    return bank ? [bank] : [];
  });
}

async function cachePostMedia(bucket: Bucket, doc: PostDoc): Promise<MediaItem[]> {
  const MAX_CACHED = 4;
  const out: MediaItem[] = [];
  for (const [index, item] of doc.media.entries()) {
    if (index >= MAX_CACHED) {
      out.push(item);
      continue;
    }
    const cachedUrl = await cacheImage(bucket, `posts/${doc.bank_id}/${doc.id}/${index}`, item.original_url);
    out.push(cachedUrl ? { ...item, url: cachedUrl, cached: true } : item);
  }
  return out;
}

async function upsertPosts(db: Firestore, docs: PostDoc[]): Promise<void> {
  if (docs.length === 0) return;
  const refs = docs.map((d) => db.collection("posts").doc(d.id));
  const existing = new Set((await db.getAll(...refs)).filter((s) => s.exists).map((s) => s.id));

  const batch = db.batch();
  docs.forEach((doc, i) => {
    const payload = {
      ...doc,
      posted_at: Timestamp.fromDate(doc.posted_at),
      last_synced_at: FieldValue.serverTimestamp(),
      // Only stamped on first insert, so it records when we first saw the post.
      ...(existing.has(doc.id) ? {} : { first_seen_at: FieldValue.serverTimestamp() }),
    };
    batch.set(refs[i] as FirebaseFirestore.DocumentReference, payload, { merge: true });
  });
  await batch.commit();
}

async function processBank(ctx: Context, bank: BankDoc): Promise<BankResult> {
  const bankRef = ctx.db.collection("banks").doc(bank.id);
  try {
    const raw = await withRetry(
      () => ctx.provider.fetchPosts(bank, { since: ctx.since, limit: ctx.cfg.maxPostsPerBank }),
      { attempts: 2, baseDelayMs: 5_000, label: bank.id },
    );
    const recent = raw.filter((p) => p.postedAt >= ctx.since);
    const docs = recent.map((p) => buildPostDoc(bank, p, ctx.provider.name));

    if (ctx.bucket) {
      for (const doc of docs) doc.media = await cachePostMedia(ctx.bucket, doc);
    }

    await upsertPosts(ctx.db, docs);
    await bankRef.update({
      last_fetched_at: FieldValue.serverTimestamp(),
      last_fetch_status: "ok",
      last_fetch_count: docs.length,
      last_error: null,
    });
    log(`✓ ${bank.id}: ${docs.length} post(s) upserted`);
    return { bankId: bank.id, ok: true, fetched: raw.length, written: docs.length };
  } catch (err) {
    const message = errorMessage(err).slice(0, 500);
    log(`✗ ${bank.id}: ${message}`);
    await bankRef
      .update({ last_fetched_at: FieldValue.serverTimestamp(), last_fetch_status: "error", last_error: message })
      .catch((e: unknown) => log(`  could not record failure for ${bank.id}: ${errorMessage(e)}`));
    return { bankId: bank.id, ok: false, fetched: 0, written: 0, error: message };
  }
}

async function main(): Promise<void> {
  const cfg = loadConfig();
  const { db, bucket } = initFirebase(cfg);
  const provider: PostProvider = new ApifyProvider(cfg.apifyToken);

  const banks = await loadBanks(db, cfg.onlyBankId);
  if (banks.length === 0) {
    log("No active banks found. Add some in the admin UI or run `npm run seed`.");
    return;
  }

  const since = new Date(Date.now() - cfg.lookbackHours * 3_600_000);
  log(`Ingesting ${banks.length} bank(s) via ${provider.name}; window since ${since.toISOString()}; media cache: ${cfg.cacheMedia}`);

  const ctx: Context = { db, bucket, provider, cfg, since };
  const results = await runPool(banks, cfg.concurrency, (bank) => processBank(ctx, bank));

  const failed = results.filter((r) => !r.ok);
  const written = results.reduce((sum, r) => sum + r.written, 0);
  log(`Done. ${results.length - failed.length}/${results.length} banks ok, ${written} posts upserted.`);
  if (failed.length > 0) log(`Failed banks: ${failed.map((f) => f.bankId).join(", ")}`);

  // One flaky page should not turn the whole schedule red, but a systemic failure must.
  if (failed.length === results.length || failed.length / results.length > 0.5) {
    throw new Error("More than half of the banks failed; treating the run as failed.");
  }
}

main().catch((err: unknown) => {
  console.error(err);
  process.exit(1);
});
