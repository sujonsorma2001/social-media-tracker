import { cert, getApps, initializeApp } from "firebase-admin/app";
import { getFirestore, type Firestore } from "firebase-admin/firestore";
import { getStorage } from "firebase-admin/storage";
import type { Config } from "./config";

export type Bucket = ReturnType<ReturnType<typeof getStorage>["bucket"]>;

export function initFirebase(cfg: Config): { db: Firestore; bucket: Bucket | null } {
  const app =
    getApps()[0] ??
    initializeApp({
      credential: cert(cfg.serviceAccount),
      ...(cfg.storageBucket ? { storageBucket: cfg.storageBucket } : {}),
    });
  const db = getFirestore(app);
  db.settings({ ignoreUndefinedProperties: true });
  return { db, bucket: cfg.cacheMedia ? getStorage(app).bucket() : null };
}
