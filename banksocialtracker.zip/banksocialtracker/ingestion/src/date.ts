/**
 * Asia/Dhaka date helpers.
 * KEEP IN SYNC with web/src/lib/date.ts (the two packages deploy separately).
 */
export const DHAKA_TZ = "Asia/Dhaka";

const dhakaFormatter = new Intl.DateTimeFormat("en-US", {
  timeZone: DHAKA_TZ,
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
});

/** Converts an instant to the calendar day (`YYYY-MM-DD`) it falls on in Dhaka. */
export function toDhakaDateKey(date: Date): string {
  if (Number.isNaN(date.getTime())) throw new RangeError("Invalid Date passed to toDhakaDateKey");
  const parts = dhakaFormatter.formatToParts(date);
  const pick = (type: Intl.DateTimeFormatPartTypes): string => {
    const value = parts.find((p) => p.type === type)?.value;
    if (!value) throw new Error(`Intl did not return a "${type}" part`);
    return value;
  };
  return `${pick("year")}-${pick("month")}-${pick("day")}`;
}

export function isValidDateKey(key: string): boolean {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(key);
  if (!m) return false;
  const y = Number(m[1]);
  const mo = Number(m[2]);
  const d = Number(m[3]);
  const dt = new Date(Date.UTC(y, mo - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === mo - 1 && dt.getUTCDate() === d;
}
