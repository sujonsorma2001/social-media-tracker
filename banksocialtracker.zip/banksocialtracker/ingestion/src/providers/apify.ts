import { ApifyClient } from "apify-client";
import type { BankDoc, RawMedia, RawPost } from "../types";
import type { FetchOptions, PostProvider } from "./types";

/**
 * Apify "Facebook Posts Scraper". Facebook blocks datacenter IPs (including GitHub Actions
 * runners), so scraping through a managed provider is far more reliable than DIY.
 *
 * VERIFY BEFORE GOING LIVE: actor output fields change over time. Run the actor once on a
 * bank page, inspect the dataset JSON, and adjust the field names in `mapItem` / `mapMedia`
 * below. All provider-specific knowledge is isolated in this file.
 */
const ACTOR_ID = "apify/facebook-posts-scraper";

type Json = Record<string, unknown>;

const isRecord = (v: unknown): v is Json => typeof v === "object" && v !== null && !Array.isArray(v);

const str = (v: unknown): string | null => (typeof v === "string" && v.trim() !== "" ? v.trim() : null);

function num(...candidates: unknown[]): number {
  for (const c of candidates) {
    if (typeof c === "number" && Number.isFinite(c)) return c;
    if (typeof c === "string" && c.trim() !== "" && Number.isFinite(Number(c))) return Number(c);
  }
  return 0;
}

function parseTime(item: Json): Date | null {
  const iso = str(item.time);
  if (iso) {
    const d = new Date(iso);
    if (!Number.isNaN(d.getTime())) return d;
  }
  const ts = item.timestamp;
  if (typeof ts === "number" && Number.isFinite(ts)) {
    const d = new Date(ts < 1e12 ? ts * 1000 : ts); // seconds vs milliseconds
    if (!Number.isNaN(d.getTime())) return d;
  }
  return null;
}

function idFromUrl(url: string): string | null {
  const byPath = /\/(?:posts|videos|reel|photos?|permalink)\/([^/?#]+)/.exec(url);
  if (byPath?.[1]) return byPath[1];
  try {
    return new URL(url).searchParams.get("fbid") ?? new URL(url).searchParams.get("story_fbid");
  } catch {
    return null;
  }
}

function mapMedia(item: Json): RawMedia[] {
  const list = Array.isArray(item.media) ? item.media : [];
  const out: RawMedia[] = [];
  for (const entry of list) {
    if (!isRecord(entry)) continue;
    const typename = (str(entry.__typename) ?? "").toLowerCase();
    const videoUrl = str(entry.video_url) ?? str(entry.playable_url) ?? str(entry.videoUrl);
    const imageUrl =
      str(entry.thumbnail) ??
      (isRecord(entry.photo_image) ? str(entry.photo_image.uri) : null) ??
      (isRecord(entry.image) ? str(entry.image.uri) : null) ??
      str(entry.imageUri);
    out.push({
      kind: videoUrl || typename.includes("video") ? "video" : "image",
      imageUrl,
      videoUrl,
    });
  }
  return out;
}

function mapItem(item: Json): RawPost | null {
  const permalink = str(item.url) ?? str(item.topLevelUrl);
  const fbPostId = str(item.postId) ?? (permalink ? idFromUrl(permalink) : null);
  const postedAt = parseTime(item);
  if (!permalink || !fbPostId || !postedAt) return null;

  return {
    fbPostId,
    permalink,
    caption: str(item.text) ?? "",
    postedAt,
    media: mapMedia(item),
    reactionsCount: num(item.likes, item.reactionsCount, item.topReactionsCount),
    commentsCount: num(item.comments, item.commentsCount),
    sharesCount: num(item.shares, item.sharesCount),
  };
}

export class ApifyProvider implements PostProvider {
  readonly name = "apify";
  private readonly client: ApifyClient;

  constructor(token: string) {
    this.client = new ApifyClient({ token });
  }

  async fetchPosts(bank: BankDoc, { since, limit }: FetchOptions): Promise<RawPost[]> {
    const run = await this.client.actor(ACTOR_ID).call(
      {
        startUrls: [{ url: bank.facebook_url }],
        resultsLimit: limit,
        onlyPostsNewerThan: since.toISOString(),
      },
      { waitSecs: 600 },
    );
    if (run.status !== "SUCCEEDED") {
      throw new Error(`Apify run ${run.id} ended with status ${run.status}`);
    }

    const { items } = await this.client.dataset(run.defaultDatasetId).listItems({ limit: limit * 2 });

    const byId = new Map<string, RawPost>();
    let firstError: string | null = null;
    for (const raw of items) {
      if (!isRecord(raw)) continue;
      const post = mapItem(raw);
      if (post) {
        byId.set(post.fbPostId, post);
      } else if (!firstError) {
        firstError = str(raw.errorDescription) ?? str(raw.error);
      }
    }

    // Distinguish "page has no recent posts" (fine) from "page could not be read" (error).
    if (byId.size === 0 && firstError) throw new Error(`Scraper returned an error item: ${firstError}`);

    return [...byId.values()];
  }
}
