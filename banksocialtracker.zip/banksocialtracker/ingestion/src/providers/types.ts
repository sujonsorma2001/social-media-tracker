import type { BankDoc, RawPost } from "../types";

export interface FetchOptions {
  /** Only posts at or after this instant are wanted. */
  since: Date;
  limit: number;
}

/**
 * A source of public Facebook page posts. Implement this to add Graph API,
 * Meta Content Library, or another vendor without touching the pipeline.
 */
export interface PostProvider {
  readonly name: string;
  /** Throws if the page could not be fetched (so the bank is marked as failed). */
  fetchPosts(bank: BankDoc, options: FetchOptions): Promise<RawPost[]>;
}
