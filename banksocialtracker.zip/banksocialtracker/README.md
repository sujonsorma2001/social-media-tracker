# BankSocialTracker

Track what ~50 Bangladeshi banks posted on Facebook on any chosen day (Eid, Pohela Boishakh, 16 December…).

```
GitHub Actions (cron, every 6h) ──► ingestion/ (Node + TS) ──► Apify Facebook scraper
                                         │  upsert posts, cache images
                                         ▼
                               Firestore  +  Cloud Storage
                                         ▲
Browser ──► Next.js on Vercel ──► /api/* (verifies Firebase ID token, Admin SDK)
   └── Firebase Auth (Google / email-password)
```

```
banksocialtracker/
├─ .github/workflows/fetch-posts.yml   scheduled ingestion
├─ ingestion/                          Node 20 + TypeScript job (providers/, normalize, upsert, media cache, seed)
├─ web/
│  ├─ .env.example
│  └─ src/
│     ├─ app/                          pages (/, /login, /admin/banks, /admin/campaigns) + api/ routes
│     ├─ components/                   CalendarFilter, FilterBar, PostGrid, PostCard, admin/*
│     ├─ hooks/  lib/                  data hooks, firebase.ts, firebase-admin.ts, auth, validation
├─ docs/DATA_MODEL.md                  schemas + indexes
├─ firestore.rules  firestore.indexes.json  firebase.json
```

## Read this first: where the posts come from

Facebook has no public "posts by date" API, and its Graph API only returns posts for Pages you manage (or, for others'
pages, requires Meta app review for *Page Public Content Access*). Scraping directly from GitHub Actions also gets
blocked quickly because Facebook rejects datacenter IPs. So ingestion goes through a managed scraper (Apify) behind a
small `PostProvider` interface (`ingestion/src/providers/`). Before launch:

1. **Check terms and legal posture** with whoever owns this at your organization. Scraping may breach Facebook's terms.
2. **Verify the field mapping.** Run the Apify actor once on one bank page, compare its JSON to `mapItem`/`mapMedia`
   in `ingestion/src/providers/apify.ts`, and adjust names if they differ. That file is the only place that knows
   the vendor's output format.
3. Check Apify's per-result pricing: 50 pages × 4 runs/day. Lower the cron frequency if cost matters.

## Setup

### 1. Firebase
1. Create a project at <https://console.firebase.google.com>. Enable **Firestore** (production mode), **Authentication**
   (Google and/or Email/Password; create your users manually, the app has no self-sign-up), and **Storage**
   (Cloud Storage for Firebase may require the Blaze plan; if you stay on Spark, set `CACHE_MEDIA=false`, but previews
   will break when Facebook CDN links expire).
2. Project settings → *General* → add a **Web app** → copy the config into the `NEXT_PUBLIC_FIREBASE_*` values.
3. Project settings → *Service accounts* → **Generate new private key**. Keep the JSON out of git.
4. Deploy rules + indexes (indexes take a few minutes to build):
   ```bash
   npm i -g firebase-tools && firebase login
   firebase use <your-project-id>
   firebase deploy --only firestore
   ```

### 2. Web app scaffold (one time)
The repo ships the application code in `web/src`; the framework config comes from the official scaffolder.
```bash
# from the repo root
npx create-next-app@latest _scaffold --ts --tailwind --eslint --app --src-dir --import-alias "@/*" --use-npm
cp -rn _scaffold/. web/ && rm -rf _scaffold      # -n: never overwrite files that already exist in web/
cd web
npx shadcn@latest init                            # pick the Radix flavour (components use `asChild`)
npx shadcn@latest add button card input label select calendar badge switch dialog table skeleton
npm i firebase firebase-admin zod
cp .env.example .env.local                        # fill it in
npm run dev                                       # http://localhost:3000
```
`lucide-react` is installed by shadcn. Run `npx tsc --noEmit` once to confirm everything resolves.

### 3. Seed banks
Either use **Admin → Banks → Add bank**, or edit `ingestion/data/banks.seed.json` (real page URLs) and run:
```bash
cd ingestion && npm ci
export FIREBASE_SERVICE_ACCOUNT="$(cat /path/to/serviceAccount.json)"
npm run seed
```

### 4. GitHub Actions
Repo → Settings → Secrets and variables → Actions:

| Kind | Name | Value |
|------|------|-------|
| Secret | `FIREBASE_SERVICE_ACCOUNT` | the full service-account JSON |
| Secret | `APIFY_TOKEN` | Apify API token |
| Variable | `FIREBASE_STORAGE_BUCKET` | e.g. `my-project.firebasestorage.app` (as shown in the Storage tab) |
| Variable | `CACHE_MEDIA` | `true` (default) or `false` |

Run it once by hand: Actions → *Fetch bank posts* → **Run workflow**. Use `bank_id` to test one bank, and a large
`lookback_hours` (e.g. `720`) to **backfill** earlier festival days. Scheduled runs only look back 48 h, so start
the schedule *before* the days you want to track. Note that GitHub pauses scheduled workflows in repos with no
activity for 60 days.

### 5. Vercel
1. Push the repo to GitHub. Vercel → **Add New → Project** → import it.
2. **Root Directory: `web`**. Framework preset: Next.js (auto-detected).
3. Add environment variables (Production *and* Preview) from `web/.env.example`:
   `NEXT_PUBLIC_FIREBASE_*` (6), `FIREBASE_PROJECT_ID`, `FIREBASE_CLIENT_EMAIL`, `FIREBASE_PRIVATE_KEY`
   (paste the key exactly as in the JSON, `\n` sequences included), `ADMIN_EMAILS`, `ALLOWED_EMAILS`.
   `NEXT_PUBLIC_*` values are baked in at build time, so **redeploy after changing them**.
4. Deploy. Then Firebase console → Authentication → Settings → **Authorized domains** → add your `*.vercel.app` /
   custom domain, or Google sign-in will fail with `auth/unauthorized-domain`.
5. From now on every push to `main` deploys to production and every PR gets a preview URL.

## Access control
- Every API route verifies the Firebase ID token server-side. The `AuthGate` redirect is only UX.
- `ALLOWED_EMAILS` (emails or `@domain.com`) limits who can read. If it is empty, any account that can sign in can read.
  Keep sign-up closed (create users yourself) and set this in production.
- `ADMIN_EMAILS` limits who can manage banks/campaigns, and the email must be verified (Google accounts are).

## Troubleshooting
| Symptom | Cause / fix |
|---|---|
| "database index … not deployed" | `firebase deploy --only firestore`; wait until the indexes show *Enabled*. |
| Empty day, banks show "Failed" | Open Admin → Banks, hover the badge for `last_error`; usually a private/renamed page or scraper change. |
| Images vanish after a few days | `CACHE_MEDIA` is off or bucket not set; uncached Facebook CDN URLs expire. |
| `auth/unauthorized-domain` | Add the domain to Firebase Auth authorized domains. |
| Posts land on the wrong day | They don't: `post_date` is computed in Asia/Dhaka at ingest. Check the post's `posted_at`. |
